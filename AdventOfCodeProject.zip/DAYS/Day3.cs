﻿using AdventOfCode;

namespace $safeprojectname$.days
{
    internal class Day3 : IDaySolution
    {

        public void SolutionPart1(string data)
        {
            Console.WriteLine("Not yet implemented");
        }

        public void SolutionPart2(string data)
        {
            Console.WriteLine("Not yet implemented");
        }
    }
}
